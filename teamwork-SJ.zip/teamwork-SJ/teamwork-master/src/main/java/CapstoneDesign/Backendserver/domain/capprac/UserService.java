package CapstoneDesign.Backendserver.domain.capprac;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Objects;

@Service
@Transactional
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;
    @Transactional
    //user에 필요한 정보가 담겨있을때
    public int join(User user) {
        JoinValidateDuplicateUser(user);
        userRepository.saveorupdate(user);
        return user.getUsIndex();
    }
    private void JoinValidateDuplicateUser(User user) {
        User findUsers = userRepository.findByUserId(user.getUsId());
        if(findUsers!=null) {
            throw new IllegalStateException("이미 존재하는 회원입니다.");
        }
    }
    public User login(String usId, String usPw) {
        User user = userRepository.findByUserId(usId);
        if(user != null && user.getUsPw().equals(usPw)) {
            return user;
        }
        return null; // 로그인 실패
    }
    //user:변경될 정보
    @Transactional
    public User updateUserInfo(User user) {
        // 기존 정보를 불러오고 변경할 정보로 업데이트
        User existingUser = userRepository.findByUserId(user.getUsId());
        if(existingUser != null) {
            existingUser.setUsPw(user.getUsPw());
            existingUser.setUsName(user.getUsName());
            existingUser.setUsFixIP(user.getUsFixIP());
            existingUser.setUsFixdate(user.getUsFixdate());
            // 필요한 정보를 더 업데이트
            userRepository.saveorupdate(existingUser);
            return existingUser;
        }
        return null; // 사용자를 찾을 수 없음
    }

    public void logout(HttpServletRequest request) {
        request.getSession().invalidate();
    }
    public void withdraw(String userId) {
        userRepository.deleteByUserId(userId);
    }
}

