package CapstoneDesign.Backendserver.domain.capprac;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class Hello {
    private String data;
}
