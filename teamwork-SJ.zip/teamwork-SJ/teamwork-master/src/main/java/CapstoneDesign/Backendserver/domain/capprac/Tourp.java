package CapstoneDesign.Backendserver.domain.capprac;

import lombok.Getter;
import lombok.Setter;
import jakarta.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "TOURP")
@Getter
@Setter
public class Tourp {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "tourp_index")
    private int tourpIndex;

    @ManyToOne
    @JoinColumn(name = "tourp_usid", nullable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "tourp_tourid", nullable = false)
    private Tour tour;

    // 람복 라이브러리를 사용하기 때문에, 별도로 Getter와 Setter 메서드를 정의할 필요가 없습니다.
}
