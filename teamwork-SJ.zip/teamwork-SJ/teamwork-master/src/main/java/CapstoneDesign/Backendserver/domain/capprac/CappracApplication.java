package CapstoneDesign.Backendserver.domain.capprac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CappracApplication {

	public static void main(String[] args) {
		SpringApplication.run(CappracApplication.class, args);
	}

}
