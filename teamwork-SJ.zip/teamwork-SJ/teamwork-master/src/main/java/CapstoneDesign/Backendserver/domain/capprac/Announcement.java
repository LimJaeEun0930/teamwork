package CapstoneDesign.Backendserver.domain.capprac;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "ANNOUNCEMENT")
@Getter
@Setter
@NoArgsConstructor // 기본 생성자 자동 생성
public class Announcement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int anmIndex;

    @Column(nullable = false, length = 60)
    private String anmName;

    @Column(nullable = false, length = 100)
    private String anmPeriod;

    @Column(nullable = false, length = 60)
    private String anmEmptype;

    @Column(nullable = false)
    private int anmRecruitm;

    @ManyToOne
    @JoinColumn(name = "anmCpid", nullable = false)
    private Company anmCpid;
}
