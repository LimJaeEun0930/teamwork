package CapstoneDesign.Backendserver.domain.capprac;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import java.util.List;

public class CompanyRepository {

    @PersistenceContext
    private EntityManager entityManager;

    // Create - 새로운 Company 저장
    public void save(Company company) {
        entityManager.persist(company);
    }

    // Read - cpIndex로 Company 찾기
    public Company findCompanyByIndex(int cpIndex) {
        return entityManager.find(Company.class, cpIndex);
    }

    // Read - 모든 Company 찾기
    public List<Company> findAllCompanies() {
        TypedQuery<Company> query = entityManager.createQuery("SELECT c FROM Company c", Company.class);
        return query.getResultList();
    }

    // Update - Company 업데이트
    public void update(Company company) {
        entityManager.merge(company);
    }

    // Delete - cpIndex로 Company 삭제
    public void deleteByIndex(int cpIndex) {
        Company company = findCompanyByIndex(cpIndex);
        if (company != null) {
            entityManager.remove(company);
        }
    }

    // Read - cpId로 단일 Company 찾기
    public Company findCompanyById(String cpId) {
        TypedQuery<Company> query = entityManager.createQuery(
                "SELECT c FROM Company c WHERE c.cpId = :cpId", Company.class);
        query.setParameter("cpId", cpId);
        return query.getSingleResult();
    }

    // Read - cpName으로 단일 Company 찾기
    public Company findCompanyByName(String cpName) {
        TypedQuery<Company> query = entityManager.createQuery(
                "SELECT c FROM Company c WHERE c.cpName = :cpName", Company.class);
        query.setParameter("cpName", cpName);
        return query.getSingleResult();
    }

    // Read - cpAddr로 단일 Company 찾기
    public Company findCompanyByAddr(String cpAddr) {
        TypedQuery<Company> query = entityManager.createQuery(
                "SELECT c FROM Company c WHERE c.cpAddr = :cpAddr", Company.class);
        query.setParameter("cpAddr", cpAddr);
        return query.getSingleResult();
    }

    // Read - cpCategory로 Company 찾기
    public List<Company> findCompaniesByCategory(String cpCategory) {
        TypedQuery<Company> query = entityManager.createQuery(
                "SELECT c FROM Company c WHERE c.cpCategory = :cpCategory", Company.class);
        query.setParameter("cpCategory", cpCategory);
        return query.getResultList();
    }

    // Read - cpMtid로 단일 Company 찾기
    public Company findCompanyByMtid(String cpMtid) {
        TypedQuery<Company> query = entityManager.createQuery(
                "SELECT c FROM Company c WHERE c.cpMtid = :cpMtid", Company.class);
        query.setParameter("cpMtid", cpMtid);
        return query.getSingleResult();
    }

    // Read - cpMtname으로 Company 찾기
    public List<Company> findCompaniesByMtname(String cpMtname) {
        TypedQuery<Company> query = entityManager.createQuery(
                "SELECT c FROM Company c WHERE c.cpMtname = :cpMtname", Company.class);
        query.setParameter("cpMtname", cpMtname);
        return query.getResultList();
    }
    // 추가적인 메소드들을 여기에 구현할 수 있습니다.
}
